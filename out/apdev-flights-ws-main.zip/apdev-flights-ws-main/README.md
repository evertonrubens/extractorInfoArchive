# apdev-flights-ws
Review projects from Training done in Jan-Feb 2019 - We'll continue with structuring the Mule app: Organizing Mule Projects files and sharing resources between apps. The edits will include Consuming WS, Error handling and Controlling message flow.
